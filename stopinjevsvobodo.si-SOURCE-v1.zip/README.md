# stopinjevsvobodo.si — izvorni paket

Ta mapa vsebuje urejevalni izvor statične spletne strani Stopinje v svobodo.

## Struktura
- `index.html` — glavna stran; vsebuje HTML, CSS, prevode in JavaScript.
- `utrinki.html` — preusmeritev na razdelek Utrinki na glavni strani.
- `assets/` — fotografije in druga slikovna gradiva.

## Objavljanje
Za objavo na domeni `stopinjevsvobodo.si` naložite **vsebino** mape v korensko mapo spletnega gostovanja (npr. `public_html`, `www` ali document root domene), tako da je `index.html` neposredno v korenu.

## Nadaljnje dopolnjevanje
Ta ZIP hranite kot glavno izvorno različico. Pri naslednjih popravkih uporabite najnovejši SOURCE paket; po spremembah ustvarite nov PUBLIC paket za objavo.
